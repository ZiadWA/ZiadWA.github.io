Recorded from the game by Sysastic/Ziad A.
Not affiliated with BANDAI NAMCO Entertainment. 
Please don't use any of the voice tracks for NSFW purposes.